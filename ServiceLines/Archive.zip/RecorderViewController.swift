//
//  RecorderViewController.swift
//  ServiceLines
//
//  Created by Mac on 13/06/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit
import AVFoundation
import SCLAlertView
import SwiftLocation
import CoreLocation
import ActionSheetPicker_3_0
//import UserNotifications

class RecorderViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var paramsLabel: UILabel!
    @IBOutlet weak var recordingLabel: UILabel!
    @IBOutlet weak var activityindicator: UIActivityIndicatorView!
   
    var syncTime = TimeInterval(3600*12)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        recordingLabel.isHidden=true
        activityindicator.isHidden=true
//        UNUserNotificationCenter.current().requestAuthorization(
//            options: [.alert,.sound,.badge],
//            completionHandler: { (granted,error) in
//                
//            }
//        )
//        
//        let userValues = UserDefaults.standard
//        if let settings = userValues.array(forKey: "settings") {
//            print(settings)
//            let settingsArr = settings as! [Dictionary<String, Any>]
//            syncTime = TimeInterval(settingsArr[1]["value"] as! Int)
//        }

        
        // Do any additional setup after loading the view.
        recordingSession = AVAudioSession.sharedInstance()
        
//        do {
//            try recordingSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
//            try recordingSession.setActive(true)
//            recordingSession.requestRecordPermission() { [unowned self] allowed in
//                DispatchQueue.main.async {
//                    if allowed {
//                        //self.loadRecordingUI()
//                    } else {
//                        // failed to record!
//                    }
//                }
//            }
//        } catch {
//            // failed to record!
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func setButtonsVisible() {
        let userValues = UserDefaults.standard
        if let fileType = userValues.string(forKey: "tipofile"){
            if fileType == "REC"{
                playButton.isHidden = true
                recordButton.isHidden = false
            }
            else if fileType == "DOC"{
                recordButton.isHidden = true
                playButton.isHidden = false
            }
        }
        
        if let societa = userValues.string(forKey: "societa"), let codice = userValues.string(forKey: "codice"), let tipoFile = userValues.string(forKey: "tipofile"){
            var labelText = "Societa: \(societa) \nCodice: \(codice)  \nTipo File: \(tipoFile)"
            if let descriDoc = userValues.string(forKey: "descridoc"){
                labelText += "\nDescrizione Documento: \(descriDoc)"
            }
            
            paramsLabel.isHidden = false
            paramsLabel.text = labelText
            //paramsLabel.sizeToFit()
            paramsLabel.frame = CGRect(x:20, y:30, width: self.view.frame.width - 40, height: 160)
            paramsLabel.center.x = self.view.center.x
        }
        else{
            paramsLabel.isHidden = true
        }
        self.tabBarController?.selectedIndex = 1
    }
    
    var imagePicker: UIImagePickerController!
   
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audioPlayer: AVAudioPlayer!
    var timer: Timer!
    
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
//    @IBOutlet weak var stopButton: UIButton!
//    @IBOutlet weak var pauseButton: UIButton!
//    @IBOutlet weak var recordButton: UIButton!

    @IBAction func playButtonClicked(_ sender: UIButton) {
        displaySwitchCamAndLib()
    }
    
    func displaySwitchCamAndLib(){
        let alertController = UIAlertController(title: "Carica foto", message: "Cosa vuoi fare?", preferredStyle: .alert)
        
        let selectFromLibrary = UIAlertAction(title: "Scegli tra le foto esistenti", style: .default, handler: { (action) -> Void in
            self.imagePicker =  UIImagePickerController()
            self.imagePicker.delegate = self
            self.imagePicker.sourceType = .photoLibrary
            
            self.present(self.imagePicker, animated: true, completion: nil)
        })
        
        let takePhotoWithCam = UIAlertAction(title: "Fai una nuova foto", style: .default, handler: { (action) -> Void in
            self.imagePicker =  UIImagePickerController()
            self.imagePicker.delegate = self
            self.imagePicker.sourceType = .camera
            
            self.present(self.imagePicker, animated: true, completion: nil)
        })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            
        })
        
        alertController.addAction(selectFromLibrary)
        alertController.addAction(takePhotoWithCam)
        alertController.addAction(cancelButton)
        present(alertController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
        let imageData = info[UIImagePickerControllerOriginalImage] as! UIImage
        let data = UIImageJPEGRepresentation(imageData, 1.0)
        let imageURL = getFullRecordFilePath(typePref: "_DOC_")
        
        do{
            try data?.write(to: imageURL)
            SCLAlertView().showInfo("Info", subTitle: "l'immagine è stata salvata correttamente", closeButtonTitle: "OK")
        }
        catch{
            
        }
        
    }
    @IBAction func stopButtonClicked(_ sender: UIButton) {
                if audioRecorder != nil {
                    finishRecording(success: true)
                    recordingLabel.isHidden=true
                    activityindicator.isHidden=true
                }
        
                recordingLabel.isHidden=true
        SCLAlertView().showInfo("Info", subTitle: "Registrazione fermata, il file è stato salvato correttamente!", closeButtonTitle: "OK")
    }
    @IBAction func recordButtonClicked(_ sender: UIButton) {
                if audioRecorder == nil {
                    recordingLabel.isHidden=false
                    activityindicator.isHidden=false
                    activityindicator.activityIndicatorViewStyle=UIActivityIndicatorViewStyle.gray
                    activityindicator.startAnimating()
                    self.recordButton.setTitle("PA", for: .normal)
                    self.recordingLabel.text = "Rec..."
                    startRecording()
                }
                else if audioRecorder.isRecording{
                    audioRecorder.pause()
                    self.recordButton.setTitle("REC", for: .normal)
                    self.recordingLabel.text = "La registrazione è in pausa"
                    activityindicator.stopAnimating()
                    SCLAlertView().showInfo("Info", subTitle: "La registrazione è in pausa....")
                }
                else{
                    audioRecorder.record()
                    self.recordButton.setTitle("PA", for: .normal)
                    self.recordingLabel.text = "Rec..."
                    activityindicator.startAnimating()
                }

    }
    
    @IBAction func pauseButtonClicked(_ sender: UIButton) {

    }
    
    var recordingLimit:Int = 60
    var distanceLimit = 5 // Meters
    
    func startRecording() {
        let audioFilename = getFullRecordFilePath(typePref: "_AUD_")
        let userValues = UserDefaults.standard
        if let settings = userValues.array(forKey: "settings") {
            print(settings)
            let settingsArr = settings as! [Dictionary<String, Any>]
            recordingLimit = settingsArr[1]["value"] as! Int
            distanceLimit = Int(settingsArr[0]["value"] as! String)!
        }
        
        registerDistanceAlert()

        recordingSession = AVAudioSession.sharedInstance()
        try! recordingSession.setCategory(AVAudioSessionCategoryPlayAndRecord, with: .defaultToSpeaker)
        try! recordingSession.setActive(true)
        recordingSession.requestRecordPermission(){ [ unowned self] allowed in
            DispatchQueue.main.async{
                if allowed{
                    let settings = [
                        AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                        AVSampleRateKey: 12000,
                        AVNumberOfChannelsKey: 1,
                        AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
                    ]
                    
                    do {
                        self.audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
                        self.audioRecorder.delegate = self
                        self.audioRecorder.isMeteringEnabled = true
                        self.audioRecorder.prepareToRecord()
                        self.audioRecorder.record()
                        self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.recordingLimit), target: self,   selector: (#selector(RecorderViewController.updateTimer)), userInfo: nil, repeats: false)
                        
                        self.recordButton.setTitle("PA", for: .normal)
                        self.stopButton.isHidden = false
                    } catch {
                        self.finishRecording(success: false)
                    }
                    
                }
            }
        }
        
    }
    
    func updateTimer(){
//        if TimeInterval(recordingLimit) == audioRecorder.currentTime{
        if audioRecorder != nil {
            audioRecorder.pause()
        }
            if timer != nil{
                timer.invalidate()
                timer = nil
            }
        let appearance = SCLAlertView.SCLAppearance(
            showCloseButton: false
        )
        let alertView = SCLAlertView(appearance:appearance)
            alertView.addButton("CONTINUA"){
                if self.audioRecorder != nil {
                    self.audioRecorder.record()
                }
            }
            alertView.addButton("TERMINA REC") {
                self.stopButtonClicked(self.stopButton)
            }
            alertView.showNotice("Time Limit", subTitle: "La durata della regitrazione ha superatoe etc...")
    }
    
    func registerDistanceAlert(){
        Location.getLocation(accuracy: .room, frequency: .oneShot, success: { _,location in
            print("Found location \(location) Radius: \(self.distanceLimit)")
            do {
                try Location.monitor(regionAt: location.coordinate, radius: CLLocationDistance(self.distanceLimit), enter: { _ in
                    print("Entered in region!")
                }, exit: { _ in
                    print("Exited from the region")
                    if self.audioRecorder == nil{
                        return
                    }
                    if !self.audioRecorder.isRecording{
                        return
                    }
                    let appearance = SCLAlertView.SCLAppearance(
                        showCloseButton: false
                    )
                    let alertView = SCLAlertView(appearance:appearance)
                    alertView.addButton("CONTINUA"){
                        self.audioRecorder.record()
                    }
                    alertView.addButton("TERMINA REC") {
                        self.stopButtonClicked(self.stopButton)
                    }
                    alertView.showNotice("Distance Limit", subTitle: "La tua posizione è cambiata rispetto all'inizio registrazione, vuoi continuare?")

                }, error: { req, error in
                    print("An error has occurred \(error)")
                    req.cancel() // abort the request (you can also use `cancelOnError=true` to perform it automatically
                })
            } catch {
                print("Cannot start heading updates: \(error)")
            }

        }) { (_, last, error) in
            print("Something bad has occurred \(error)")
        }

    }
    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
    func getFullRecordFilePath(typePref: String) -> URL {
        let defaultValues = UserDefaults.standard

        var fileName = ""
        if let societa = defaultValues.string(forKey: "societa") {
            fileName += societa
        }
        else{
            fileName += "societa"
        }
        
        if let codice = defaultValues.string(forKey: "codice"){
            fileName += codice
        }
        else{
            fileName += "codice"
        }
        
        fileName += typePref
        
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMddhhmmss"
        
        fileName += formatter.string(from: date)
        
        if typePref == "_DOC_" {
            fileName += ".jpg"
        } else {
            fileName += ".m4a"
        }
        
        let documentsDirectory = getDocumentsDirectory()
//        let fileName = ""
        return documentsDirectory.appendingPathComponent(fileName)
    }
    
    func finishRecording(success: Bool) {
        if timer != nil {
            timer.invalidate()
            timer = nil
        }
        
        if audioRecorder != nil {
            print(audioRecorder.currentTime)
            audioRecorder.stop()
            audioRecorder = nil
        }
        
        if success {
            recordButton.setTitle("REC", for: .normal)
        } else {
            recordButton.setTitle("REC", for: .normal)
            // recording failed :(
        }
        self.stopButton.isHidden = true
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
            self.stopButton.isHidden = true
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
