//
//  FilesViewController.swift
//  ServiceLines
//
//  Created by Mac on 16/06/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit
import Foundation
import AVFoundation
import SCLAlertView
import Alamofire
class FilesViewController: UITableViewController, AVAudioPlayerDelegate {

   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var filesList : [[String]] = []
    let textCellIdentifier = "Cell"
    var audioPlayer: AVAudioPlayer!
    //Create a button
//    let infoButton = UIBarButtonItem(title: "Upload All", style: UIBarButtonItemStyle.plain, target: self, action: #selector(uploadAllClicked(sender:)))
    let messageFrame = UIView()
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    
    let ftpUserName = "gwapp"
    let ftpPassword = "4ds034x8$!xc$D1"
    let ftpServer = "ftp:\\webtest.servicelines.it"
    
    let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    
    func activityIndicator(_ title: String) {
        
        strLabel.removeFromSuperview()
        activityIndicator.removeFromSuperview()
        effectView.removeFromSuperview()
        
        strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
        strLabel.text = title
        strLabel.font = UIFont.systemFont(ofSize: 14, weight: UIFontWeightMedium)
        strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
        
        effectView.frame = CGRect(x: view.frame.midX - strLabel.frame.width/2, y: view.frame.midY - strLabel.frame.height/2 , width: 180, height: 46)
        effectView.layer.cornerRadius = 15
        effectView.layer.masksToBounds = true
        
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
        activityIndicator.startAnimating()
        
        effectView.addSubview(activityIndicator)
        effectView.addSubview(strLabel)
        view.addSubview(effectView)
    }

    let toolbar = UIToolbar()
    
    override func viewDidDisappear(_ animated: Bool) {
        toolbar.isHidden = true;
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //Initialize the toolbar
        
        toolbar.barStyle = UIBarStyle.default
        
        //Set the toolbar to fit the width of the app.
        toolbar.sizeToFit()
        
        //Caclulate the height of the toolbar
        let toolbarHeight = toolbar.frame.size.height
        
        //Get the bounds of the parent view
        let rootViewBounds = self.parent?.view.bounds
        
        //Get the height of the parent view.
//        let rootViewHeight = rootViewBounds?.height
        
        //Get the width of the parent view,
        let rootViewWidth = rootViewBounds?.width
        
        //Create a rectangle for the toolbar
        let rectArea = CGRect(x: 0, y: 20, width: rootViewWidth!, height: toolbarHeight)
        
        //Reposition and resize the receiver
        toolbar.frame = rectArea
        
        let infoButton = UIBarButtonItem(title: "Upload All", style: UIBarButtonItemStyle.plain, target: self, action: #selector(uploadAllClicked(sender:)))

        toolbar.items = [infoButton]
        
        //Add the toolbar as a subview to the navigation controller.
        self.tabBarController?.view.addSubview(toolbar)
        self.tableView.contentInset = UIEdgeInsets(top: toolbarHeight + 20, left: 0, bottom: 0, right: 0)
        let filemanager:FileManager = FileManager()
        let docPath = getDocumentsDirectory()
        do{
            let filelist = try filemanager.contentsOfDirectory(atPath: docPath)
            filesList.removeAll()
            for filename in filelist{
                let filePath = docPath + "/" + filename
                let fileSize = (try! FileManager.default.attributesOfItem(atPath: filePath)[FileAttributeKey.size] as! NSNumber).uint64Value / 1024
                
                filesList.append([filename, String(fileSize) + " Kbytes"])
            }
            tableView.reloadData()
        }catch let error{
            print("Error: \(error.localizedDescription)")
        }

    }
    func uploadAllClicked(sender:UIBarButtonItem){
//        infoButton.isEnabled = false
        activityIndicator("Caricamento di tutti i files....")
        DispatchQueue.main.async {
            self.uploadAllFiles()
            DispatchQueue.main.async {
                self.effectView.removeFromSuperview()
//                self.infoButton.isEnabled = true
            }
        }
    }
    
    func uploadAllFiles(){
        
        let ftp = CkoFtp2()
            
            var success: Bool
            
            //  Any string unlocks the component for the 1st 30-days.
            success = (ftp?.unlockComponent("Anything for 30-day trial"))!
            if success != true {
                print("\(ftp?.lastErrorText)")
                return
            }
            
            ftp?.hostname = ftpServer
            ftp?.username = ftpUserName
            ftp?.password = ftpPassword
            
            //  Connect and login to the FTP server.
            success = (ftp?.connect())!
            if success != true {
                print("\(ftp?.lastErrorText)")
                let dialog = UIAlertController(title: "Error", message: "Cannot connect server using your login information!", preferredStyle: UIAlertControllerStyle.alert)
                dialog.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                present(dialog, animated: true, completion: nil)
                return
            }
            
            //  Upload a file.
            let documentDir = getDocumentsDirectory()
            
            for fileName in filesList {
                let localPath = documentDir + "/" + fileName[0]
                
                success = (ftp?.putFile(localPath, remoteFilename: fileName[0]))!
                if success != true {
                    print("\(ftp?.lastErrorText)")
                    return
                }
                
                self.deleteFileByName(fileName[0])

            }
            success = (ftp?.disconnect())!
        
        self.filesList.removeAll()
        self.tableView.reloadData()
        
            let dialog = UIAlertController(title: "Success", message: "Tutti i files sono stati caricati correttamente sul Server e sono stati cancellati dal dispositivo", preferredStyle: UIAlertControllerStyle.actionSheet)
            dialog.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            present(dialog, animated: true, completion: nil)
            print("All File Uploaded!")
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        toolbar.isHidden = false;
        let defaultValues = UserDefaults.standard
        let loggedIn = defaultValues.string(forKey:"username")
        if loggedIn == nil{
            let appearance = SCLAlertView.SCLAppearance(
                showCloseButton: false
            )
            let alert = SCLAlertView(appearance: appearance)
            let userName = alert.addTextField("User Name:")
            let password = alert.addTextField("Password")
            password.isSecureTextEntry = true
            alert.addButton("Accedi") {
                print("User Name: \(userName.text)")
                print("Password: \(password.text)")
                
                let txtUserName = userName.text! as String
                let txtPassword = password.text! as String
                let parameters: Parameters = ["username": txtUserName, "password": txtPassword]
                Alamofire.request("http://web.servicelines.it:82/test/gwapp/ws_login.php", parameters: parameters, encoding: URLEncoding.default).responseJSON { response in
                    print("Request: \(String(describing: response.request))")   // original url request
                    print("Response: \(String(describing: response.response))") // http url response
                    print("Result: \(response.result)")                         // response serialization result
                    
                    if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                        if utf8Text.lowercased().range(of:"status: 1") != nil {
                            defaultValues.set(txtUserName, forKey: "username")
                            defaultValues.set(txtPassword, forKey: "password")
                        }
                        else{
                            SCLAlertView().showInfo("Error", subTitle: "Username o Password errati!", closeButtonTitle: "OK")
                            self.tabBarController?.selectedIndex = 1
                        }
                    }
                }
            }
            alert.addButton("Annulla"){
                self.tabBarController?.selectedIndex = 1
            }

            alert.showEdit("Elenco registrazioni", subTitle: "")
        }

    }
    
    func getDocumentsDirectory() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        return path
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return filesList.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        
        // Configure the cell...
        cell.textLabel?.text = filesList[indexPath.row][0]
        cell.detailTextLabel?.text = filesList[indexPath.row][1]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let fileName = filesList[indexPath.row][0]
        let playAction = UITableViewRowAction(style: .normal, title: "Giocare"){
            (rowAction, indexPath) in
            self.requestPlayFile(indexPath)
        }
        
        let stopAction = UITableViewRowAction(style: .normal, title: "Stop"){
            (rowAction, indexPath) in
            self.stopFile(indexPath)
        }
        
        let imagePreviewAction = UITableViewRowAction(style: .normal, title: "Anteprima"){
            (rowAction, indexPath) in
            self.previewImage(indexPath)
        }
        
        let uploadAction = UITableViewRowAction(style: .normal, title: "Caricare"){
            (rowAction, indexPath) in
            self.requestUploadFile(indexPath)
        }
        
        let deleteAction = UITableViewRowAction(style: .default, title: "Elimina"){
            (rowAction, indexPath) in
            self.deleteFile(indexPath)
            SCLAlertView().showInfo("Info", subTitle: "Il file è stato cancellato correttamente", closeButtonTitle: "OK")

        }
        
        playAction.backgroundColor = UIColor.blue
        stopAction.backgroundColor = UIColor.darkGray
        uploadAction.backgroundColor = UIColor.purple
        deleteAction.backgroundColor = UIColor.brown
        
        if fileName.range(of:"AUD") != nil{
            return [deleteAction, uploadAction, stopAction, playAction]
        }else {
            return [deleteAction, uploadAction, imagePreviewAction]
        }
    }
    
    func previewImage(_ indexPath: IndexPath){
//        let appearance = SCLAlertView.SCLAppearance(
//            kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
//            kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
//            kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
//            showCloseButton: false
//        )
        
        // Initialize SCLAlertView using custom Appearance
        let alert = SCLAlertView()
        
        // Creat the subview
        let subview = UIView(frame: CGRect(x:0,y:0,width:300,height:340))
        
        // Add textfield 1
        let imageView = UIImageView(frame: CGRect(x:10,y:10,width:280,height:320))
        let imageFilename = getDocumentsDirectory() + "/" + filesList[indexPath.row][0]
        //let pathURL = URL(string: audioFilename)!
//        let url = URL(fileURLWithPath: imageFilename)
        let image    = UIImage(contentsOfFile: imageFilename)
        imageView.image = image
        imageView.contentMode = .scaleAspectFill
        subview.addSubview(imageView)
        
        // Add the subview to the alert's UI property
        alert.customSubview = subview
        
        alert.showInfo("Anteprima", subTitle: "", closeButtonTitle: "Vicino")
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        self.effectView.removeFromSuperview()
    }
    
    var recordingSession: AVAudioSession!

    func requestPlayFile(_ indexPath:IndexPath){
        let fileName = filesList[indexPath.row][0]
        activityIndicator("Playing file \(fileName) ...")
        DispatchQueue.main.async {
            self.playFile(fileName)
            DispatchQueue.main.async {
//                self.effectView.removeFromSuperview()
                //                self.infoButton.isEnabled = true
            }
        }
//        recordingSession = AVAudioSession.sharedInstance()
//        
//                do {
//                    try recordingSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
//                    try recordingSession.setActive(true)
//                    self.playFile(fileName)
//                } catch {
//                    // failed to record!
//                }

    }
    
    func playFile(_ fileName: String){
        let audioFilename = getDocumentsDirectory() + "/" + fileName
        //let pathURL = URL(string: audioFilename)!
        let url = URL(fileURLWithPath: audioFilename)
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer.delegate = self
            audioPlayer.prepareToPlay()
            audioPlayer.volume = 1.0
            audioPlayer.play()
        }catch{
            
        }
    }
    
    func stopFile(_ indexPath: IndexPath){
        if audioPlayer != nil{
            audioPlayer.stop()
        }
        self.effectView.removeFromSuperview()
    }
   
    func deleteFileByName(_ fileName: String){
        let filePath = getDocumentsDirectory() + "/" + fileName
        let fileManager = FileManager.default
        do{
            try fileManager.removeItem(atPath: filePath)
        }
        catch {
        }
    }
    
    func deleteFile(_ indexPath: IndexPath){
        let fileName = filesList[indexPath.row]
        let filePath = getDocumentsDirectory() + "/" + fileName[0]
        
        let fileManager = FileManager.default
        
        do{
            try fileManager.removeItem(atPath: filePath)
            self.filesList.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        catch {
            
        }
    }
    
    func requestUploadFile(_ indexPath: IndexPath){
        let fileName = filesList[indexPath.row]
        activityIndicator("Caricamento di ....")
        DispatchQueue.main.async {
            if self.uploadFile(fileName[0]) {
                self.deleteFile(indexPath)
                self.tableView.reloadData()
                DispatchQueue.main.async {
                    self.effectView.removeFromSuperview()
                    SCLAlertView().showInfo("Info", subTitle: "File caricato correttamente!", closeButtonTitle: "OK")
                    //                self.infoButton.isEnabled = true
                }
            }
        }

    }
    func uploadFile(_ fileName: String) -> Bool{
        
        let ftp = CkoFtp2()
            
            var success: Bool
            
            //  Any string unlocks the component for the 1st 30-days.
            success = (ftp?.unlockComponent("Anything for 30-day trial"))!
            if success != true {
                print("\(ftp?.lastErrorText)")
                return false
            }
            
            ftp?.hostname = ftpServer
            ftp?.username = ftpUserName
            ftp?.password = ftpPassword
            
            //  Connect and login to the FTP server.
            success = (ftp?.connect())!
            if success != true {
                print("\(ftp?.lastErrorText)")
                let dialog = UIAlertController(title: "Error", message: "Cannot connect server using your login information!", preferredStyle: UIAlertControllerStyle.alert)
                dialog.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                present(dialog, animated: true, completion: nil)
                return false
            }
            
            //  Upload a file.
            let documentDir = getDocumentsDirectory()
            let localPath = documentDir + "/" + fileName
            
            success = (ftp?.putFile(localPath, remoteFilename: fileName))!
            if success != true {
                print("\(ftp?.lastErrorText)")
                return false
            }
            
            success = (ftp?.disconnect())!
        
            print("File Uploaded!")
        return true
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
